package com.example.carapp;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    // Data display TextViews
    private TextView tvBattery, tvCurrent, tvSmoke, tvObstacle, tvCarStatus;

    // Control Buttons
    private Button btnConnect, btnForward, btnBackward, btnLeft, btnRight, btnStop;

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private InputStream inputStream;
    private OutputStream outputStream;
    private Handler handler = new Handler();
    private StringBuilder stringBuilder = new StringBuilder();

    // Standard SPP UUID for serial communication
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    // Replace with your HC‑05 device address
    private static final String DEVICE_ADDRESS = "00:23:00:01:75:DA";

    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_BLUETOOTH_PERMISSIONS = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize data display views
        tvBattery = findViewById(R.id.tvBattery);
        tvCurrent = findViewById(R.id.tvCurrent);
        tvSmoke = findViewById(R.id.tvSmoke);
        tvObstacle = findViewById(R.id.tvObstacle);
        tvCarStatus = findViewById(R.id.tvCarStatus);

        // Initialize control buttons
        btnConnect = findViewById(R.id.btnConnect);
        btnForward = findViewById(R.id.btnForward);
        btnBackward = findViewById(R.id.btnBackward);
        btnLeft = findViewById(R.id.btnLeft);
        btnRight = findViewById(R.id.btnRight);
        btnStop = findViewById(R.id.btnStop);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth not supported on this device", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!hasBluetoothPermissions()) {
            requestBluetoothPermissions();
        }

        // Set up connect button listener
        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!bluetoothAdapter.isEnabled()) {
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                } else {
                    connectToBluetooth();
                }
            }
        });

        // Set up control buttons listeners
        btnForward.setOnClickListener(view -> {
            sendCommand("F");
            tvCarStatus.setText("Car Status: Moving Forward");
        });
        btnBackward.setOnClickListener(view -> {
            sendCommand("B");
            tvCarStatus.setText("Car Status: Moving Backward");
        });
        btnLeft.setOnClickListener(view -> {
            sendCommand("L");
            tvCarStatus.setText("Car Status: Turning Left");
        });
        btnRight.setOnClickListener(view -> {
            sendCommand("R");
            tvCarStatus.setText("Car Status: Turning Right");
        });
        btnStop.setOnClickListener(view -> {
            sendCommand("S");
            tvCarStatus.setText("Car Status: Stopped");
        });
    }

    private boolean hasBluetoothPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBluetoothPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.BLUETOOTH_CONNECT
        }, REQUEST_BLUETOOTH_PERMISSIONS);
    }

    private void connectToBluetooth() {
        try {
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(DEVICE_ADDRESS);
            bluetoothSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
            bluetoothSocket.connect();

            inputStream = bluetoothSocket.getInputStream();
            outputStream = bluetoothSocket.getOutputStream();

            Toast.makeText(this, "Connected to Bluetooth device", Toast.LENGTH_SHORT).show();
            receiveData();
        } catch (IOException e) {
            Log.e(TAG, "Error connecting to Bluetooth device: " + e.getMessage());
            Toast.makeText(this, "Connection failed. Ensure the Bluetooth device is accessible.", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendCommand(String command) {
        if (outputStream != null) {
            try {
                outputStream.write(command.getBytes());
            } catch (IOException e) {
                Toast.makeText(MainActivity.this, "Failed to send command", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(MainActivity.this, "Bluetooth not connected", Toast.LENGTH_SHORT).show();
        }
    }

    private void receiveData() {
        byte[] buffer = new byte[1024];
        final int[] bytes = new int[1];

        new Thread(() -> {
            while (true) {
                try {
                    bytes[0] = inputStream.read(buffer);
                    String data = new String(buffer, 0, bytes[0]);
                    Log.d(TAG, "Raw Received Data: " + data); // Debugging raw data
                    stringBuilder.append(data);
                    int endOfLineIndex = stringBuilder.indexOf("\n");
                    if (endOfLineIndex > 0) {
                        String dataIn = stringBuilder.substring(0, endOfLineIndex);
                        stringBuilder.delete(0, endOfLineIndex + 1);
                        Log.d(TAG, "Formatted Data: " + dataIn); // Debugging formatted data
                        runOnUiThread(() -> parseData(dataIn));
                    }
                } catch (IOException e) {
                    Log.e(TAG, "Error reading data: " + e.getMessage());
                    break;
                }
            }
        }).start();
    }

    private void parseData(String data) {
        try {
            Log.d(TAG, "Parsed Data: " + data);
            String[] parts = data.split(",");
            boolean obstacleFound = false;

            for (String part : parts) {
                if (part.startsWith("Voltage:")) {
                    float voltage = Float.parseFloat(part.substring(8).trim());
                    tvBattery.setText("Battery Voltage: " + voltage + "V");
                } else if (part.startsWith("Current:")) {
                    float current = Float.parseFloat(part.substring(8).trim());
                    tvCurrent.setText("Current: " + current + "A");
                } else if (part.startsWith("Smoke:")) {
                    int smokeLevel = Integer.parseInt(part.substring(6).trim());
                    tvSmoke.setText(smokeLevel == 1 ? "Smoke: Detected" : "Smoke: Not Detected");
                } else if (part.startsWith("Obstacle:")) {
                    obstacleFound = true;
                    int obstacle = Integer.parseInt(part.substring(9).trim());
                    tvObstacle.setText(obstacle == 1 ? "Obstacle: Detected" : "Obstacle: Not Detected");
                }
            }

            if (!obstacleFound) {
                tvObstacle.setText("Obstacle: Data Not Received");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error parsing data: " + e.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BT && resultCode == RESULT_OK) {
            connectToBluetooth();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_BLUETOOTH_PERMISSIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                connectToBluetooth();
            } else {
                Toast.makeText(this, "Bluetooth permission is required for this app", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
